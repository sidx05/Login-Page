# signUp
A simple signUp page made using java servlets, mysql database.

You must have following installed

1.Tomcat7. <br />
2.Mysql database 


Steps to set-Up

1. Clone the repositoy into inside your webapps directory on your machine. The path in my machine was "/var/lib/tomcat7/webapps"

2. Execute the command
```bash
mysql -u root -p < createDatabase.sql
```
3. Start Tomcat7
```bash
/etc/init.d/tomcat7 start
```
...to be continued